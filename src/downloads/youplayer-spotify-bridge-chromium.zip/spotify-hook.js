(() => {
  const PAGE_SOURCE = "youplayer-spotify-page";
  const CONTENT_SOURCE = "youplayer-spotify-content";
  const TOKEN_URL = "/get_access_token?reason=transport&productType=web_player";
  const originalFetch = window.fetch.bind(window);
  let enabled = false;

  function emitToken(token, expiresAt = 0, isAnonymous = null) {
    if (!enabled) return;
    const value = String(token || "").replace(/^Bearer\s+/i, "").trim();
    if (value.length < 40) return;
    window.postMessage({
      source: PAGE_SOURCE,
      type: "token",
      token: value,
      expiresAt: Number(expiresAt) || 0,
      isAnonymous: typeof isAnonymous === "boolean" ? isAnonymous : null
    }, window.location.origin);
  }

  function requestUrl(input) {
    if (typeof input === "string") return input;
    if (input instanceof URL) return input.href;
    return input?.url || "";
  }

  function inspectRequest(input, init = {}) {
    const url = requestUrl(input);
    if (!/https:\/\/(api-partner|api)\.spotify\.com\//i.test(url)) return;
    try {
      const headers = new Headers(init.headers || input?.headers || {});
      emitToken(headers.get("authorization"));
    } catch {
      // Une requete non standard ne doit jamais casser le WebPlayer.
    }
  }

  function emitPathfinderOperation(payload) {
    if (!enabled) return;
    const operationName = String(payload?.operationName || "");
    const sha256Hash = String(payload?.extensions?.persistedQuery?.sha256Hash || "").toLowerCase();
    if (!operationName || !/^[a-f0-9]{64}$/.test(sha256Hash)) return;
    window.postMessage({
      source: PAGE_SOURCE,
      type: "pathfinder-operation",
      operationName,
      sha256Hash
    }, window.location.origin);
  }

  function inspectPathfinderPayload(rawBody) {
    if (!rawBody) return;
    try {
      emitPathfinderOperation(typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody);
    } catch {
      // Les corps non JSON ne concernent pas Pathfinder.
    }
  }

  async function inspectPathfinderRequest(input, init = {}) {
    const url = requestUrl(input);
    if (!/https:\/\/api-partner\.spotify\.com\/pathfinder\//i.test(url)) return;
    if (init.body) {
      inspectPathfinderPayload(init.body);
      return;
    }
    if (typeof input !== "string" && input?.clone) {
      try {
        inspectPathfinderPayload(await input.clone().text());
      } catch {
        // L'interception du bearer reste active si le corps ne peut pas etre clone.
      }
    }
  }

  window.fetch = function youplayerSpotifyFetch(input, init) {
    if (enabled) {
      inspectRequest(input, init);
      inspectPathfinderRequest(input, init);
    }
    return originalFetch(input, init);
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function youplayerSpotifyOpen(method, url, ...rest) {
    this.__youplayerSpotifyUrl = enabled ? String(url || "") : "";
    this.__youplayerSpotifyAuthorization = "";
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function youplayerSpotifyHeader(name, value) {
    if (enabled && String(name).toLowerCase() === "authorization") {
      this.__youplayerSpotifyAuthorization = String(value || "");
    }
    return originalSetRequestHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function youplayerSpotifySend(...args) {
    if (enabled && /https:\/\/(api-partner|api)\.spotify\.com\//i.test(this.__youplayerSpotifyUrl || "")) {
      emitToken(this.__youplayerSpotifyAuthorization);
    }
    if (enabled && /https:\/\/api-partner\.spotify\.com\/pathfinder\//i.test(this.__youplayerSpotifyUrl || "")) {
      inspectPathfinderPayload(args[0]);
    }
    return originalSend.apply(this, args);
  };

  async function refreshWebPlayerToken() {
    if (!enabled) return;
    try {
      const response = await originalFetch(TOKEN_URL, {
        credentials: "include",
        cache: "no-store",
        headers: { Accept: "application/json" }
      });
      if (!response.ok) return;
      const data = await response.json();
      emitToken(
        data?.accessToken,
        data?.accessTokenExpirationTimestampMs,
        data?.isAnonymous
      );
    } catch {
      // L'interception reseau reste disponible si cet endpoint change.
    }
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    if (event.data?.source === CONTENT_SOURCE && event.data?.type === "bridge-enabled") {
      enabled = event.data.enabled === true;
    }
    if (event.data?.source === CONTENT_SOURCE && event.data?.type === "refresh-token") {
      refreshWebPlayerToken();
    }
  });

  window.setInterval(refreshWebPlayerToken, 10 * 60 * 1000);
})();
