import {
  SPOTIFY_PATHFINDER_URL,
  SpotifyBrowserError,
  normalizedOptions,
  pathfinderJson
} from "./spotify-pathfinder.js";
import {
  normalizeArtist,
  normalizeAlbum,
  normalizeTrack,
  normalizePlaylist,
  albumTracks,
  normalizeAlbumDetail,
  normalizeArtistDetail
} from "./spotify-normalizers.js";

// Preserve the public API consumed by YouPlayer and existing extension tests.
export { SpotifyBrowserError } from "./spotify-pathfinder.js";
const LIBRARY_PAGE_SIZE = 50;
const PLAYLIST_PAGE_SIZE = 100;
export const LIKED_SONGS_PLAYLIST_ID = "youplayerlikedtracks";

function playlistVariables(playlistId, offset, limit) {
  return {
    uri: `spotify:playlist:${playlistId}`,
    offset,
    limit,
    enableWatchFeedEntrypoint: false
  };
}

export async function fetchBrowserSpotifySearch(accessToken, query, fetchOrOptions = {}) {
  const searchTerm = String(query || "").trim();
  if (!searchTerm) throw new SpotifyBrowserError(400, "Recherche Spotify vide");
  if (searchTerm.length > 200) throw new SpotifyBrowserError(400, "Recherche Spotify trop longue");
  const options = normalizedOptions(fetchOrOptions);
  const limit = Math.min(50, Math.max(1, Number(fetchOrOptions?.limit) || 16));
  const offset = Math.min(10000, Math.max(0, Number(fetchOrOptions?.offset) || 0));
  const json = await pathfinderJson("searchDesktop", {
    searchTerm,
    offset,
    limit,
    numberOfTopResults: 5,
    includeAudiobooks: true,
    includeArtistHasConcertsField: false,
    includePreReleases: true,
    includeAlbumPreReleases: false,
    includeAuthors: false,
    includeEpisodeContentRatingsV2: true,
    isPrefix: null,
    sectionFilters: ["GENERIC"]
  }, accessToken, options);
  const search = json?.data?.searchV2;
  if (!search) throw new SpotifyBrowserError(502, "Resultats Spotify Pathfinder introuvables");
  const tracks = (search.tracksV2?.items || []).map(normalizeTrack).filter((item) => item.name || item.id);
  const playlists = (search.playlists?.items || []).map(normalizePlaylist).filter(Boolean);
  const albums = (search.albumsV2?.items || []).map(normalizeAlbum).filter((item) => item.name || item.id);
  const artists = (search.artists?.items || []).map(normalizeArtist).filter((item) => item.name || item.id);
  return {
    tracks: { items: tracks, total: Number(search.tracksV2?.totalCount) || tracks.length },
    playlists: { items: playlists, total: Number(search.playlists?.totalCount) || playlists.length },
    albums: { items: albums, total: Number(search.albumsV2?.totalCount) || albums.length },
    artists: { items: artists, total: Number(search.artists?.totalCount) || artists.length }
  };
}

export async function fetchBrowserSpotifyAlbum(accessToken, albumId, fetchOrOptions = {}) {
  const id = String(albumId || "").trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(id)) throw new SpotifyBrowserError(400, "Identifiant d'album Spotify invalide");
  const options = normalizedOptions(fetchOrOptions);
  const tracks = [];
  let metadata = null;
  let offset = 0;
  let total = 0;
  do {
    const json = await pathfinderJson("getAlbum", {
      uri: `spotify:album:${id}`,
      locale: "fr",
      offset,
      limit: 50
    }, accessToken, options);
    const album = json?.data?.albumUnion;
    if (!album) throw new SpotifyBrowserError(404, "Album Spotify introuvable");
    if (!metadata) metadata = album;
    const pageTracks = albumTracks(album);
    tracks.push(...pageTracks);
    total = Math.max(total, Number(album?.tracksV2?.totalCount || album?.tracks?.totalCount) || 0, tracks.length);
    offset += pageTracks.length;
    if (pageTracks.length === 0 || pageTracks.length < 50) break;
  } while (offset < total && offset < 10000);
  return normalizeAlbumDetail(metadata, tracks);
}

export async function fetchBrowserSpotifyArtist(accessToken, artistId, fetchOrOptions = {}) {
  const id = String(artistId || "").trim();
  if (!/^[A-Za-z0-9]{10,64}$/.test(id)) throw new SpotifyBrowserError(400, "Identifiant d'artiste Spotify invalide");
  const options = normalizedOptions(fetchOrOptions);
  const json = await pathfinderJson("queryArtistOverview", {
    uri: `spotify:artist:${id}`,
    locale: "fr",
    preReleaseV2: true
  }, accessToken, options);
  const artist = json?.data?.artistUnion;
  if (!artist) throw new SpotifyBrowserError(404, "Artiste Spotify introuvable");
  return normalizeArtistDetail(artist);
}

export async function fetchBrowserSpotifyPlaylists(accessToken, fetchOrOptions = {}) {
  const options = normalizedOptions(fetchOrOptions);
  const playlists = new Map();
  const visitedOffsets = new Set();
  let offset = 0;
  let totalCount = 0;

  while (!visitedOffsets.has(offset) && visitedOffsets.size < 200) {
    visitedOffsets.add(offset);
    const json = await pathfinderJson("libraryV3", {
      filters: ["Playlists"],
      order: null,
      textFilter: null,
      features: [],
      limit: LIBRARY_PAGE_SIZE,
      offset,
      flatten: true,
      folderUri: null,
      includeFoldersWhenFlattening: true
    }, accessToken, options);
    const library = json?.data?.me?.libraryV3;
    if (!library || library.__typename && library.__typename !== "LibraryPage") {
      throw new SpotifyBrowserError(502, "Bibliotheque Spotify Pathfinder introuvable");
    }
    const rawItems = Array.isArray(library.items) ? library.items : [];
    for (const rawItem of rawItems) {
      const playlist = normalizePlaylist(rawItem);
      if (playlist) playlists.set(playlist.id, playlist);
    }
    totalCount = Math.max(totalCount, Number(library.totalCount) || 0);
    offset += rawItems.length;
    if (rawItems.length === 0 || rawItems.length < LIBRARY_PAGE_SIZE || offset >= totalCount) break;
  }

  const likedSongs = {
    id: LIKED_SONGS_PLAYLIST_ID,
    name: "Titres likes",
    description: "Titres enregistres dans la bibliotheque Spotify",
    uri: "spotify:collection:tracks",
    images: [],
    owner: { id: "", display_name: "Bibliotheque Spotify" },
    tracks: { total: 0 },
    external_urls: { spotify: "https://open.spotify.com/collection/tracks" }
  };
  const items = [likedSongs, ...playlists.values()];
  return {
    href: SPOTIFY_PATHFINDER_URL,
    items,
    limit: LIBRARY_PAGE_SIZE,
    offset: 0,
    total: items.length,
    next: null
  };
}

export async function fetchBrowserSpotifyLikedTracks(accessToken, fetchOrOptions = {}) {
  const options = normalizedOptions(fetchOrOptions);
  const tracks = [];
  const visitedOffsets = new Set();
  let offset = 0;
  let total = 0;

  while (!visitedOffsets.has(offset) && visitedOffsets.size < 200) {
    visitedOffsets.add(offset);
    const json = await pathfinderJson(
      "fetchLibraryTracks",
      { offset, limit: LIBRARY_PAGE_SIZE },
      accessToken,
      options
    );
    const page = json?.data?.me?.library?.tracks;
    if (!page || page.__typename && page.__typename !== "UserLibraryTrackPage") {
      throw new SpotifyBrowserError(502, "Titres likes Spotify introuvables");
    }
    const rawItems = Array.isArray(page.items) ? page.items : [];
    tracks.push(...rawItems.map(normalizeTrack).filter((track) => track.id));
    total = Math.max(total, Number(page.totalCount) || 0, offset + rawItems.length);
    offset += rawItems.length;
    if (rawItems.length === 0 || rawItems.length < LIBRARY_PAGE_SIZE || offset >= total) break;
  }

  return {
    id: LIKED_SONGS_PLAYLIST_ID,
    name: "Titres likes",
    description: "Titres enregistres dans la bibliotheque Spotify",
    uri: "spotify:collection:tracks",
    images: [],
    owner: { id: "", display_name: "Bibliotheque Spotify" },
    external_urls: { spotify: "https://open.spotify.com/collection/tracks" },
    tracks: {
      href: SPOTIFY_PATHFINDER_URL,
      items: tracks.map((track) => ({ track })),
      limit: tracks.length,
      offset: 0,
      total: Math.max(total, tracks.length),
      next: null
    }
  };
}

export async function fetchBrowserSpotifyPlaylist(accessToken, playlistId, fetchOrOptions = {}) {
  const id = String(playlistId || "").trim();
  if (id === LIKED_SONGS_PLAYLIST_ID) {
    return fetchBrowserSpotifyLikedTracks(accessToken, fetchOrOptions);
  }
  if (!/^[A-Za-z0-9]{10,64}$/.test(id)) {
    throw new SpotifyBrowserError(400, "Identifiant de playlist Spotify invalide");
  }
  const options = normalizedOptions(fetchOrOptions);
  const metadataJson = await pathfinderJson(
    "fetchPlaylist",
    playlistVariables(id, 0, 1),
    accessToken,
    options
  );
  const metadata = metadataJson?.data?.playlistV2;
  if (!metadata) throw new SpotifyBrowserError(404, "Playlist Spotify introuvable");

  const tracks = [];
  let offset = 0;
  let total = Number(metadata?.content?.totalCount) || 0;
  while (offset < Math.max(total, PLAYLIST_PAGE_SIZE)) {
    const pageJson = await pathfinderJson(
      "fetchPlaylistContents",
      playlistVariables(id, offset, PLAYLIST_PAGE_SIZE),
      accessToken,
      options
    );
    const content = pageJson?.data?.playlistV2?.content;
    const rawItems = Array.isArray(content?.items) ? content.items : [];
    total = Math.max(total, Number(content?.totalCount) || 0, offset + rawItems.length);
    tracks.push(...rawItems.map(normalizeTrack).filter((track) => track.name || track.id));
    offset += rawItems.length;
    if (rawItems.length === 0 || rawItems.length < PLAYLIST_PAGE_SIZE || offset >= total) break;
  }

  const playlist = normalizePlaylist({ data: metadata }) || {
    id,
    name: metadata.name || "Playlist Spotify",
    uri: `spotify:playlist:${id}`,
    images: [],
    owner: {},
    external_urls: { spotify: `https://open.spotify.com/playlist/${id}` }
  };
  return {
    ...playlist,
    tracks: {
      href: SPOTIFY_PATHFINDER_URL,
      items: tracks.map((track) => ({ track })),
      limit: tracks.length,
      offset: 0,
      total: Math.max(total, tracks.length),
      next: null
    }
  };
}

// Return only lyrics; bearer and upstream metadata never cross the app bridge.
export async function fetchBrowserSpotifyLyrics(accessToken, trackId, fetchOrOptions = {}) {
  if (typeof trackId !== "string" || !/^[A-Za-z0-9]{22}$/.test(trackId)) {
    throw new SpotifyBrowserError(400, "Identifiant de titre Spotify invalide");
  }
  const { fetchImpl } = normalizedOptions(fetchOrOptions);
  let response;
  try {
    response = await fetchImpl(`https://spclient.wg.spotify.com/color-lyrics/v2/track/${trackId}?format=json&market=from_token`, {
      headers: { Authorization: `Bearer ${accessToken}`, "App-Platform": "WebPlayer", Accept: "application/json" },
      redirect: "error", signal: AbortSignal.timeout(12000)
    });
  } catch {
    throw new SpotifyBrowserError(502, "Paroles Spotify indisponibles");
  }
  if (!response.ok) {
    await response.body?.cancel();
    if (response.status === 404) return { available: true, found: false };
    const retry = Number(response.headers.get("retry-after"));
    throw new SpotifyBrowserError(response.status, "Paroles Spotify indisponibles", {
      retryAfterSeconds: Number.isFinite(retry) ? Math.min(3600, Math.max(0, retry)) : 0
    });
  }
  let lyrics;
  try {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let text = "", size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > 1_000_000) throw new Error();
        text += decoder.decode(value, { stream: true });
      }
      text += decoder.decode();
    } finally { await reader.cancel(); }
    lyrics = JSON.parse(text).lyrics;
    if (!["LINE_SYNCED", "UNSYNCED"].includes(lyrics?.syncType)
      || !Array.isArray(lyrics.lines) || lyrics.lines.length > 2000) throw new Error();
    let length = 0, previous = -1;
    for (const line of lyrics.lines) {
      if (typeof line.words !== "string" || (length += line.words.length) > 100_000) throw new Error();
      if (lyrics.syncType === "LINE_SYNCED") {
        const time = Number(line.startTimeMs);
        if (!/^\d+$/.test(String(line.startTimeMs)) || !Number.isSafeInteger(time)
          || time < previous || time > 86_400_000) throw new Error();
        previous = time;
      }
    }
  } catch {
    throw new SpotifyBrowserError(502, "Réponse de paroles Spotify invalide");
  }
  if (!lyrics.lines.some(line => line.words.trim())) return { available: true, found: false };
  return {
    available: true, found: true, source: "Spotify",
    sourceUrl: `https://open.spotify.com/track/${trackId}`,
    plainLyrics: lyrics.lines.map(line => line.words).join("\n"),
    timedLines: lyrics.syncType === "LINE_SYNCED"
      ? lyrics.lines.map(line => ({ time: Number(line.startTimeMs) / 1000, text: line.words })) : []
  };
}
