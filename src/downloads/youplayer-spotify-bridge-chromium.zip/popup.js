import {
  getAllowedYouPlayerOrigins,
  normalizeYouPlayerOrigin,
  pairYouPlayerOrigin,
  youPlayerOriginMatchPattern
} from "./youplayer-origin.js";

const extensionApi = globalThis.browser ?? globalThis.chrome;
const statusElement = document.getElementById("status");
const spotifyState = document.getElementById("spotify-state");
const youPlayerOriginInput = document.getElementById("youplayer-origin");
const pairCurrentButton = document.getElementById("pair-current");
const openYouPlayerButton = document.getElementById("open-youplayer");
const pairingFeedback = document.getElementById("pairing-feedback");
const refreshButton = document.getElementById("refresh-status");
const toggleButton = document.getElementById("toggle-enabled");
let bridgeEnabled = true;
let currentTabOrigin = "";
let pairedOrigin = "";

async function refreshStatus() {
  refreshButton.disabled = true;
  try {
    const response = await extensionApi.runtime.sendMessage({ action: "status" });
    if (!response?.ok) throw new Error("Statut indisponible");
    const status = response.data || {};
    bridgeEnabled = status.enabled !== false;
    toggleButton.textContent = bridgeEnabled ? "Désactiver l’extension" : "Activer l’extension";
    toggleButton.setAttribute("aria-checked", String(bridgeEnabled));
    toggleButton.disabled = false;
    document.getElementById("open-spotify").disabled = !bridgeEnabled;
    if (!bridgeEnabled) {
      spotifyState.textContent = "Désactivée";
      spotifyState.dataset.state = "waiting";
      statusElement.textContent = "Extension en pause. Votre association YouPlayer est conservée.";
      return;
    }
    const ready = status.authenticated && status.tokenCaptured;
    spotifyState.textContent = ready ? "Connecté" : "À connecter";
    spotifyState.dataset.state = ready ? "ready" : "waiting";
    statusElement.textContent = ready
      ? "Votre session Spotify est prête à être utilisée."
      : status.anonymous && status.tokenCaptured
        ? "Connectez-vous à votre compte dans Spotify, puis rechargez sa page."
        : status.spotifyTabOpen
          ? "Rechargez la page Spotify, puis cliquez sur Vérifier."
          : "Ouvrez Spotify et connectez-vous à votre compte.";
  } catch {
    spotifyState.textContent = "Indisponible";
    spotifyState.dataset.state = "error";
    statusElement.textContent = "Impossible de vérifier Spotify. Cliquez sur Vérifier pour réessayer.";
  } finally {
    refreshButton.disabled = false;
  }
}

function showPairing(origin) {
  pairedOrigin = origin;
  const state = document.getElementById("youplayer-state");
  state.textContent = origin ? "Associé" : "À associer";
  state.dataset.state = origin ? "ready" : "waiting";
  document.getElementById("youplayer-address").textContent = origin || "Associez l’adresse de votre YouPlayer pour commencer.";
  document.getElementById("connection-settings").open = !origin;
  openYouPlayerButton.disabled = !origin;
}

function pairingMessage(text, state) {
  pairingFeedback.textContent = text;
  pairingFeedback.dataset.state = state;
}

document.getElementById("open-spotify").addEventListener("click", async () => {
  try {
    const response = await extensionApi.runtime.sendMessage({ action: "open-spotify" });
    if (!response?.ok) throw new Error("Ouverture impossible");
    window.close();
  } catch {
    statusElement.textContent = "Impossible d’ouvrir Spotify. Réessayez ou ouvrez open.spotify.com.";
  }
});

openYouPlayerButton.addEventListener("click", async () => {
  if (!pairedOrigin) return;
  try {
    await extensionApi.tabs.create({ url: `${pairedOrigin}/?view=parametres` });
    window.close();
  } catch {
    pairingMessage("Impossible d’ouvrir YouPlayer. Réessayez.", "error");
  }
});

async function pairOrigin(value) {
  try {
    const origin = await pairYouPlayerOrigin(extensionApi, value);
    youPlayerOriginInput.value = origin;
    showPairing(origin);
    pairingMessage("YouPlayer associé. Rechargez sa page pour activer la connexion.", "ready");
  } catch {
    pairingMessage("Association impossible. Vérifiez l’adresse HTTPS et acceptez la permission demandée.", "error");
  }
}

pairCurrentButton.addEventListener("click", () => {
  if (currentTabOrigin) void pairOrigin(currentTabOrigin);
});

document.getElementById("origin-form").addEventListener("submit", (event) => {
  event.preventDefault();
  void pairOrigin(youPlayerOriginInput.value);
});

refreshButton.addEventListener("click", refreshStatus);
toggleButton.addEventListener("click", async () => {
  toggleButton.disabled = true;
  try {
    const response = await extensionApi.runtime.sendMessage({ action: "set-enabled", enabled: !bridgeEnabled });
    if (!response?.ok) throw new Error("Modification impossible");
    await refreshStatus();
  } catch {
    statusElement.textContent = "Impossible de modifier l’activation. Réessayez.";
  } finally {
    toggleButton.disabled = false;
  }
});

// Firefox requires permissions.request before the click handler yields.
extensionApi.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  currentTabOrigin = normalizeYouPlayerOrigin(tab?.url);
  if (currentTabOrigin === "https://open.spotify.com") currentTabOrigin = "";
  pairCurrentButton.disabled = !currentTabOrigin;
  pairCurrentButton.hidden = !currentTabOrigin;
  document.getElementById("current-tab").textContent = currentTabOrigin
    ? `Onglet actuel : ${currentTabOrigin}`
    : "Saisissez l’adresse de votre YouPlayer ci-dessous.";
}).catch(() => {
  document.getElementById("current-tab").textContent = "Saisissez l’adresse HTTPS de votre YouPlayer ci-dessous.";
});

getAllowedYouPlayerOrigins(extensionApi).then(async (origins) => {
  const [origin] = origins;
  if (origin) youPlayerOriginInput.value = origin;
  const permitted = origin && await extensionApi.permissions.contains({ origins: [youPlayerOriginMatchPattern(origin)] });
  showPairing(permitted ? origin : "");
}).catch(() => {
  pairingMessage("Impossible de lire l’association. Fermez puis rouvrez l’extension.", "error");
});

void refreshStatus();
