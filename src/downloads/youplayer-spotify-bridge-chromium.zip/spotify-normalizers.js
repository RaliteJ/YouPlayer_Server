function spotifyId(uri = "") {
  return String(uri || "").split(":").pop() || "";
}

function imageSources(...candidates) {
  for (const candidate of candidates) {
    if (!candidate) continue;
    if (Array.isArray(candidate)) {
      const direct = candidate.filter((item) => item?.url);
      if (direct.length > 0) {
        return direct.map((item) => ({
          url: item.url,
          width: item.width || null,
          height: item.height || null
        }));
      }
      const nested = candidate.flatMap((item) => item?.sources || item?.data?.sources || []);
      if (nested.length > 0) return imageSources(nested);
    }
    if (candidate.sources) return imageSources(candidate.sources);
    if (candidate.items) return imageSources(candidate.items);
    if (candidate.url) return imageSources([candidate]);
  }
  return [];
}

function pathfinderData(item) {
  return item?.itemV2?.data
    || item?.item?.data
    || item?.track?.data
    || item?.track
    || item?.data
    || item?.featured?.data
    || item
    || {};
}

export function normalizeArtist(item) {
  const data = pathfinderData(item);
  const id = spotifyId(data.uri) || data.id || "";
  return {
    id,
    name: data.profile?.name || data.name || "",
    uri: data.uri || (id ? `spotify:artist:${id}` : ""),
    external_urls: id ? { spotify: `https://open.spotify.com/artist/${id}` } : {}
  };
}

function normalizeArtists(artists) {
  const items = artists?.items || artists || [];
  return Array.isArray(items)
    ? items.map(normalizeArtist).filter((artist) => artist.name || artist.id)
    : [];
}

export function normalizeAlbum(item) {
  const data = pathfinderData(item);
  const id = spotifyId(data.uri) || data.id || "";
  return {
    id,
    name: data.name || "",
    uri: data.uri || (id ? `spotify:album:${id}` : ""),
    artists: normalizeArtists(data.artists),
    images: imageSources(data.coverArt, data.visualIdentity?.squareCoverImage, data.images),
    release_date: data.date?.isoString || (data.date?.year ? String(data.date.year) : ""),
    total_tracks: Number(data.tracksV2?.totalCount || data.tracks?.totalCount || data.totalTracks) || 0,
    external_urls: id ? { spotify: `https://open.spotify.com/album/${id}` } : {}
  };
}

export function normalizeTrack(item) {
  const data = pathfinderData(item);
  const wrapperUri = item?.track?._uri || item?.itemV2?._uri || item?.item?._uri || item?._uri || "";
  const uri = data.uri || wrapperUri;
  const id = String(uri).startsWith("spotify:track:") ? spotifyId(uri) : data.id || "";
  return {
    id,
    name: data.name || data.title || "",
    uri: uri || (id ? `spotify:track:${id}` : ""),
    artists: normalizeArtists(data.artists),
    album: normalizeAlbum(data.albumOfTrack || data.album || {}),
    track_number: data.trackNumber || data.track_number || 0,
    duration_ms: data.duration?.totalMilliseconds || data.duration_ms || 0,
    explicit: Boolean(data.contentRating?.label === "EXPLICIT" || data.explicit),
    external_urls: id ? { spotify: `https://open.spotify.com/track/${id}` } : {}
  };
}

export function normalizePlaylist(item) {
  const wrapper = item?.item || item;
  const data = wrapper?.data || wrapper;
  if (wrapper?.__typename && wrapper.__typename !== "PlaylistResponseWrapper") return null;
  if (data?.__typename && data.__typename !== "Playlist") return null;
  const id = spotifyId(data?.uri) || data?.id || spotifyId(wrapper?._uri);
  if (!id) return null;
  const owner = data?.ownerV2?.data || data?.owner || {};
  return {
    id,
    name: data?.name || "",
    description: data?.description || "",
    uri: data?.uri || `spotify:playlist:${id}`,
    images: imageSources(data?.images, data?.coverArt, data?.visualIdentity?.image),
    owner: {
      id: owner.id || spotifyId(owner.uri),
      display_name: owner.name || owner.displayName || owner.username || ""
    },
    tracks: { total: Number(data?.content?.totalCount) || 0 },
    external_urls: { spotify: `https://open.spotify.com/playlist/${id}` }
  };
}

export function albumTracks(album = {}) {
  const direct = album?.tracksV2?.items || album?.tracks?.items || [];
  const discs = album?.discs?.items || [];
  return [
    ...(Array.isArray(direct) ? direct : []),
    ...discs.flatMap((disc) => disc?.tracks?.items || [])
  ];
}

export function normalizeAlbumDetail(albumUnion = {}, rawTracks = albumTracks(albumUnion)) {
  const album = normalizeAlbum(albumUnion);
  const tracks = rawTracks
    .map((item) => normalizeTrack(item?.track || item))
    .filter((track) => track.name || track.id)
    .map((track) => ({
      ...track,
      album: {
        id: album.id,
        name: album.name,
        images: album.images,
        external_urls: album.external_urls
      }
    }));
  return {
    ...album,
    total_tracks: album.total_tracks || tracks.length,
    tracks: { items: tracks, total: tracks.length }
  };
}

function releaseItems(section = {}) {
  const items = section?.items || [];
  return items.flatMap((item) => item?.releases?.items || item?.items || [item]);
}

export function normalizeArtistDetail(artistUnion = {}) {
  const artist = normalizeArtist(artistUnion);
  const discography = artistUnion?.discography || {};
  const releaseSections = [
    discography.popularReleasesAlbums,
    discography.albums,
    discography.singles,
    discography.compilations
  ];
  const albumsById = new Map();
  for (const release of releaseSections.flatMap(releaseItems)) {
    const album = normalizeAlbum(release?.data || release);
    if (album.id && !albumsById.has(album.id)) albumsById.set(album.id, album);
  }
  const topTrackItems = discography.topTracks?.items || artistUnion?.topTracks?.items || [];
  const relatedItems = artistUnion?.relatedContent?.relatedArtists?.items
    || artistUnion?.relatedArtists?.items
    || [];
  return {
    artist,
    albums: [...albumsById.values()],
    top_tracks: topTrackItems
      .map((item) => normalizeTrack(item?.track || item))
      .filter((track) => track.name || track.id),
    related_artists: relatedItems
      .map(normalizeArtist)
      .filter((related) => related.name || related.id)
  };
}

