export const DEFAULT_YOUPLAYER_ORIGIN = "https://127.0.0.1:8443";
const ORIGIN_KEY = "youplayerOrigin";
const CONTENT_SCRIPT_ID = "youplayer-origin-bridge";

export function normalizeYouPlayerOrigin(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  let url;
  try {
    url = new URL(raw);
  } catch {
    return "";
  }
  if (url.protocol !== "https:") return "";
  url.pathname = "";
  url.search = "";
  url.hash = "";
  return url.origin;
}

export function youPlayerOriginMatchPattern(value) {
  const origin = normalizeYouPlayerOrigin(value);
  if (!origin) return "";
  const url = new URL(origin);
  return `${url.protocol}//${url.hostname}/*`;
}

export async function getAllowedYouPlayerOrigins(extensionApi) {
  const configured = normalizeYouPlayerOrigin(
    (await extensionApi.storage.local.get(ORIGIN_KEY))[ORIGIN_KEY]
  );
  return new Set(configured ? [configured] : []);
}

export async function isAllowedYouPlayerOrigin(extensionApi, origin) {
  const normalized = normalizeYouPlayerOrigin(origin);
  if (!normalized) return false;
  return (await getAllowedYouPlayerOrigins(extensionApi)).has(normalized);
}

export async function getPreferredYouPlayerOrigin(extensionApi) {
  const configured = normalizeYouPlayerOrigin(
    (await extensionApi.storage.local.get(ORIGIN_KEY))[ORIGIN_KEY]
  );
  return configured || DEFAULT_YOUPLAYER_ORIGIN;
}

export async function setPreferredYouPlayerOrigin(extensionApi, value) {
  const origin = normalizeYouPlayerOrigin(value);
  if (!origin) {
    throw new Error("URL YouPlayer invalide. Utilise une adresse https://host:port");
  }
  await extensionApi.storage.local.set({ [ORIGIN_KEY]: origin });
  return origin;
}

export async function registerYouPlayerContentScript(extensionApi, value) {
  const origin = normalizeYouPlayerOrigin(value);
  const pattern = youPlayerOriginMatchPattern(origin);
  if (!origin || !pattern) throw new Error("Origine YouPlayer HTTPS invalide");
  const granted = await extensionApi.permissions.contains({ origins: [pattern] });
  if (!granted) throw new Error("Autorisation YouPlayer absente pour cet hote");
  const existing = await extensionApi.scripting.getRegisteredContentScripts({ ids: [CONTENT_SCRIPT_ID] });
  const scripts = [{
    id: CONTENT_SCRIPT_ID,
    matches: [pattern],
    js: ["youplayer-content.js"],
    runAt: "document_start"
  }];
  if (existing.length > 0) {
    await extensionApi.scripting.updateContentScripts(scripts);
  } else {
    await extensionApi.scripting.registerContentScripts(scripts);
  }
  return origin;
}

export async function pairYouPlayerOrigin(extensionApi, value) {
  const origin = normalizeYouPlayerOrigin(value);
  const pattern = youPlayerOriginMatchPattern(origin);
  if (!origin || !pattern) {
    throw new Error("URL YouPlayer invalide. Utilise une adresse https://host:port");
  }
  // Firefox requires this call before any await yields the click handler.
  const granted = await extensionApi.permissions.request({ origins: [pattern] });
  if (!granted) throw new Error("Autorisation refusee pour cette origine YouPlayer");
  const previous = await getPreferredYouPlayerOrigin(extensionApi);
  const previousPattern = youPlayerOriginMatchPattern(previous);
  await registerYouPlayerContentScript(extensionApi, origin);
  await setPreferredYouPlayerOrigin(extensionApi, origin);
  if (previousPattern && previousPattern !== pattern) {
    await extensionApi.permissions.remove({ origins: [previousPattern] }).catch(() => false);
  }
  return origin;
}

export async function restoreYouPlayerContentScript(extensionApi) {
  const origins = await getAllowedYouPlayerOrigins(extensionApi);
  const [origin] = origins;
  if (!origin) return false;
  const pattern = youPlayerOriginMatchPattern(origin);
  if (!(await extensionApi.permissions.contains({ origins: [pattern] }))) return false;
  await registerYouPlayerContentScript(extensionApi, origin);
  return true;
}
