import * as defaultSpotifyClient from "./spotify-client.js";
import { createSpotifySession } from "./spotify-session.js";
import {
  isAllowedYouPlayerOrigin as defaultIsAllowedYouPlayerOrigin,
  restoreYouPlayerContentScript as defaultRestoreYouPlayerContentScript
} from "./youplayer-origin.js";

const SPOTIFY_ORIGIN = "https://open.spotify.com";
function senderOrigin(sender) {
  try {
    return new URL(sender?.url || sender?.tab?.url || "").origin;
  } catch {
    return "";
  }
}

export function installBackgroundBridge(extensionApi, {
  spotifyClient = defaultSpotifyClient,
  isAllowedYouPlayerOrigin = defaultIsAllowedYouPlayerOrigin,
  restoreYouPlayerContentScript = defaultRestoreYouPlayerContentScript
} = {}) {
  const {
    bridgeEnabled,
    setBridgeEnabled,
    storeSpotifyToken,
    storeSpotifyContentReady,
    storePathfinderOperation,
    handleYouPlayerRequest
  } = createSpotifySession(extensionApi, spotifyClient);
  let mutations = Promise.resolve();
  function mutate(task) {
    const pending = mutations.then(task);
    mutations = pending.catch(() => {});
    return pending;
  }

  extensionApi.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const spotifySender = senderOrigin(sender) === SPOTIFY_ORIGIN;
    const captures = {
      "spotify-content-ready": storeSpotifyContentReady,
      "spotify-token": storeSpotifyToken,
      "spotify-pathfinder-operation": storePathfinderOperation
    };
    const capture = Object.hasOwn(captures, message?.action) && captures[message.action];
    if (capture) {
      if (!spotifySender) return false;
      mutate(async () => {
        if (!await bridgeEnabled()) return { ok: false, error: "Extension Spotify désactivée" };
        await capture(message);
        return { ok: true };
      }).then(sendResponse).catch(() => sendResponse({ ok: false }));
      return true;
    }

    const extensionPage = Boolean(sender?.url?.startsWith(extensionApi.runtime.getURL("")));
    if (message?.action === "set-enabled") {
      if (!extensionPage) {
        sendResponse({ ok: false, error: "Action réservée à l’extension" });
        return false;
      }
      mutate(async () => ({ ok: true, data: await setBridgeEnabled(message.enabled) }))
        .then(sendResponse).catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    Promise.resolve().then(async () => {
      if (!(await isAllowedYouPlayerOrigin(extensionApi, senderOrigin(sender))) && !extensionPage) {
        sendResponse({ ok: false, error: "Origine YouPlayer non autorisée" });
        return;
      }
      handleYouPlayerRequest(message)
        .then(sendResponse)
        .catch((error) => sendResponse({
          ok: false,
          error: error?.message || "Extension Spotify indisponible"
        }));
      return true;
    }).catch(() => sendResponse({
      ok: false,
      error: "Extension Spotify indisponible"
    }));
    return true;
  });

  extensionApi.runtime.onInstalled?.addListener(() => {
    restoreYouPlayerContentScript(extensionApi).catch(() => {});
  });
  extensionApi.runtime.onStartup?.addListener(() => {
    restoreYouPlayerContentScript(extensionApi).catch(() => {});
  });
  restoreYouPlayerContentScript(extensionApi).catch(() => {});
}
