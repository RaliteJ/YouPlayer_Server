const APP_SOURCE = "youplayer-app";
const EXTENSION_SOURCE = "youplayer-spotify-extension";
const extensionApi = globalThis.browser ?? globalThis.chrome;
const ALLOWED_ACTIONS = new Set([
  "status",
  "search",
  "get-album",
  "get-artist",
  "get-lyrics",
  "get-playlists",
  "get-playlist",
  "open-spotify"
]);

async function init() {
  const configured = (await extensionApi.storage.local.get("youplayerOrigin")).youplayerOrigin;
  if (!configured || window.location.origin !== configured) return;

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const message = event.data;
    if (message?.source !== APP_SOURCE || !ALLOWED_ACTIONS.has(message.action)) return;
    if (typeof message.requestId !== "string" || message.requestId.length < 8 || message.requestId.length > 128) return;

    extensionApi.runtime.sendMessage({
      action: message.action,
      playlistId: message.playlistId,
      albumId: message.albumId,
      artistId: message.artistId,
      trackId: message.trackId,
      query: message.query,
      limit: message.limit,
      offset: message.offset
    }).then((response) => {
      window.postMessage({
        source: EXTENSION_SOURCE,
        requestId: message.requestId,
        ...response
      }, window.location.origin);
    }).catch((error) => {
      window.postMessage({
        source: EXTENSION_SOURCE,
        requestId: message.requestId,
        ok: false,
        error: error?.message || "Extension Spotify indisponible"
      }, window.location.origin);
    });
  });

  window.postMessage({
    source: EXTENSION_SOURCE,
    type: "ready",
    installed: true
  }, window.location.origin);
}

init().catch(() => {});
