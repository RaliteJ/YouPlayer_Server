export const SPOTIFY_PATHFINDER_URL = "https://api-partner.spotify.com/pathfinder/v2/query";
const DEFAULT_QUERY_HASHES = Object.freeze({
  searchDesktop: "18173d759b3d18e057204db5f6feef97d44658dc3eb5c25c245f9a21e51970db",
  getAlbum: "6a74b456cd1735c9193d9e8ec8cc5184cad7ce13572210315229db3975964361",
  queryArtistOverview: "9f8134ef565e78621f1e1793555bd6633c5ac144ae0f89604ed3ae3f80b3c8e6",
  libraryV3: "390c78e5b951029bad359785e69b07b536a509c581cbcd0aded5e5067f187455",
  fetchLibraryTracks: "087278b20b743578a6262c2b0b4bcd20d879c503cc359a2285baf083ef944240",
  fetchPlaylist: "e4b2953f160e58e38ac025d79b5a9b3aceee5c4c716598e9830bfceb69faff5f",
  fetchPlaylistContents: "e4b2953f160e58e38ac025d79b5a9b3aceee5c4c716598e9830bfceb69faff5f"
});

export class SpotifyBrowserError extends Error {
  constructor(status, message = "", { retryAfterSeconds = 0, reason = "" } = {}) {
    const fallback = status === 401
      ? "La session Spotify du navigateur a expire"
      : status === 403
        ? "Spotify refuse cette requete WebPlayer"
        : status === 429
          ? retryAfterSeconds > 0
            ? `Limite Pathfinder atteinte. Reessaie dans ${retryAfterSeconds} secondes`
            : "Limite Pathfinder atteinte. Patiente au moins 30 secondes"
          : "Requete Spotify Pathfinder impossible";
    super(status === 429 ? fallback : message || fallback);
    this.name = "SpotifyBrowserError";
    this.status = status;
    this.retryAfterSeconds = retryAfterSeconds;
    this.reason = reason;
  }
}

function retryAfterSeconds(response) {
  const raw = response?.headers?.get?.("retry-after");
  if (!raw) return 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds) && seconds > 0) return Math.ceil(seconds);
  const date = Date.parse(raw);
  return Number.isFinite(date) ? Math.max(1, Math.ceil((date - Date.now()) / 1000)) : 0;
}

export function normalizedOptions(fetchOrOptions) {
  if (typeof fetchOrOptions === "function") {
    return { fetchImpl: fetchOrOptions, queryHashes: {} };
  }
  return {
    fetchImpl: fetchOrOptions?.fetchImpl || fetch,
    queryHashes: fetchOrOptions?.queryHashes || {}
  };
}

function queryHash(operationName, queryHashes = {}) {
  const candidate = String(queryHashes?.[operationName] || "").trim();
  return /^[a-f0-9]{64}$/i.test(candidate)
    ? candidate
    : DEFAULT_QUERY_HASHES[operationName];
}

export async function pathfinderJson(operationName, variables, accessToken, {
  fetchImpl = fetch,
  queryHashes = {}
} = {}) {
  const response = await fetchImpl(SPOTIFY_PATHFINDER_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json;charset=UTF-8",
      Accept: "application/json",
      "App-Platform": "WebPlayer"
    },
    body: JSON.stringify({
      variables,
      operationName,
      extensions: {
        persistedQuery: {
          version: 1,
          sha256Hash: queryHash(operationName, queryHashes)
        }
      }
    })
  });

  let json = {};
  try {
    json = await response.json();
  } catch {
    // Le statut HTTP reste exploitable si Pathfinder ne renvoie pas de JSON.
  }

  if (!response.ok) {
    const message = String(
      json?.error?.message || json?.message || json?.errors?.[0]?.message || ""
    ).slice(0, 180);
    const reason = String(json?.error?.reason || json?.reason || "").slice(0, 80);
    throw new SpotifyBrowserError(response.status, message, {
      retryAfterSeconds: retryAfterSeconds(response),
      reason
    });
  }

  if (Array.isArray(json?.errors) && json.errors.length > 0) {
    const message = json.errors
      .map((error) => error?.message)
      .filter(Boolean)
      .join("; ")
      .slice(0, 180);
    throw new SpotifyBrowserError(502, message || "Pathfinder a refuse la requete");
  }
  return json;
}

