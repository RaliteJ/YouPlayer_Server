import { installBackgroundBridge } from "./background-runtime.js";

installBackgroundBridge(globalThis.browser ?? globalThis.chrome);
