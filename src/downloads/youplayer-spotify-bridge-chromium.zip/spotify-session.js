import * as defaultSpotifyClient from "./spotify-client.js";

export function createSpotifySession(extensionApi, spotifyClient = defaultSpotifyClient) {
  const {
    fetchBrowserSpotifyAlbum,
    fetchBrowserSpotifyArtist,
    fetchBrowserSpotifyLyrics,
    fetchBrowserSpotifyPlaylist,
    fetchBrowserSpotifyPlaylists,
    fetchBrowserSpotifySearch
  } = spotifyClient;
  const TOKEN_KEY = "spotifyWebPlayerSession";
  const CONTENT_READY_KEY = "spotifyWebPlayerContentReady";
  const PLAYLISTS_CACHE_KEY = "spotifyPathfinderPlaylistsCacheV2";
  const RATE_LIMIT_KEY = "spotifyPathfinderRateLimit";
  const PATHFINDER_HASHES_KEY = "spotifyPathfinderQueryHashes";
  const PATHFINDER_OPERATIONS = new Set([
    "searchDesktop",
    "getAlbum",
    "queryArtistOverview",
    "libraryV3",
    "fetchLibraryTracks",
    "fetchPlaylist",
    "fetchPlaylistContents"
  ]);
  const PLAYLISTS_CACHE_MS = 5 * 60 * 1000;
  let enabled = true;
  let revision = 0;
  const settingsReady = extensionApi.storage.local.get("bridgeEnabled").then(settings => {
    enabled = settings.bridgeEnabled !== false;
  });

  async function bridgeEnabled() {
    await settingsReady;
    return enabled;
  }

  async function setBridgeEnabled(value) {
    if (typeof value !== "boolean") throw new Error("État du bridge invalide");
    await settingsReady;
    await extensionApi.storage.local.set({ bridgeEnabled: value });
    enabled = value;
    revision++;
    playlistsInFlight = null;
    await extensionApi.storage.session.remove([
      TOKEN_KEY, CONTENT_READY_KEY, PLAYLISTS_CACHE_KEY, RATE_LIMIT_KEY, PATHFINDER_HASHES_KEY
    ]);
    return { enabled };
  }

  async function requireEnabled() {
    if (!await bridgeEnabled()) throw new Error("Extension Spotify désactivée");
  }
  async function storeSpotifyToken(message) {
    const token = String(message?.token || "").replace(/^Bearer\s+/i, "").trim();
    if (token.length < 40 || token.length > 8192) return;
    const current = (await extensionApi.storage.session.get(TOKEN_KEY))[TOKEN_KEY] || {};
    if (current.token && current.token !== token) {
      await extensionApi.storage.session.remove([PLAYLISTS_CACHE_KEY, RATE_LIMIT_KEY]);
    }
    await extensionApi.storage.session.set({
      [TOKEN_KEY]: {
        token,
        expiresAt: Number(message.expiresAt) || Date.now() + 30 * 60 * 1000,
        isAnonymous: typeof message.isAnonymous === "boolean"
          ? message.isAnonymous
          : current.isAnonymous ?? null,
        capturedAt: Date.now()
      }
    });
  }

  async function rateLimitUntil() {
    return Number((await extensionApi.storage.session.get(RATE_LIMIT_KEY))[RATE_LIMIT_KEY]) || 0;
  }

  async function runSpotifyRequest(task) {
    await requireEnabled();
    const requestRevision = revision;
    const token = await authenticatedToken();
    const limitedUntil = await rateLimitUntil();
    if (limitedUntil > Date.now()) {
      const seconds = Math.max(1, Math.ceil((limitedUntil - Date.now()) / 1000));
      throw new Error(`Limite Pathfinder active. Reessaie dans ${seconds} secondes`);
    }
    try {
      if (!enabled || requestRevision !== revision) throw new Error("Extension Spotify désactivée");
      const data = await task(token);
      await requireEnabled();
      if (requestRevision !== revision || token !== await authenticatedToken()) {
        throw new Error("La session Spotify a changé. Réessaie.");
      }
      return data;
    } catch (error) {
      if (error?.status === 429 && enabled && requestRevision === revision) {
        const seconds = Math.max(30, Number(error.retryAfterSeconds) || 0);
        await extensionApi.storage.session.set({
          [RATE_LIMIT_KEY]: Date.now() + seconds * 1000
        });
      }
      throw error;
    }
  }

  let playlistsInFlight = null;

  async function cachedSpotifyPlaylists() {
    const requestRevision = revision;
    const token = await authenticatedToken();
    const cached = (await extensionApi.storage.session.get(PLAYLISTS_CACHE_KEY))[PLAYLISTS_CACHE_KEY];
    if (cached?.token === token && cached.data && Number(cached.fetchedAt) > Date.now() - PLAYLISTS_CACHE_MS) {
      return cached.data;
    }
    if (playlistsInFlight?.token !== token) {
      const pending = { token };
      pending.promise = runSpotifyRequest(async (accessToken) => {
        return fetchBrowserSpotifyPlaylists(accessToken, {
          queryHashes: await pathfinderQueryHashes()
        });
      }).then(async (data) => {
        if (!enabled || requestRevision !== revision) throw new Error("La session Spotify a changé. Réessaie.");
        await extensionApi.storage.session.set({
          [PLAYLISTS_CACHE_KEY]: { token, data, fetchedAt: Date.now() }
        });
        return data;
      }).finally(() => {
        if (playlistsInFlight === pending) playlistsInFlight = null;
      });
      playlistsInFlight = pending;
    }
    return playlistsInFlight.promise;
  }

  async function storeSpotifyContentReady() {
    await extensionApi.storage.session.set({
      [CONTENT_READY_KEY]: Date.now()
    });
  }

  async function storePathfinderOperation(message) {
    const operationName = String(message?.operationName || "");
    const sha256Hash = String(message?.sha256Hash || "").toLowerCase();
    if (!PATHFINDER_OPERATIONS.has(operationName) || !/^[a-f0-9]{64}$/.test(sha256Hash)) return;
    const current = (await extensionApi.storage.session.get(PATHFINDER_HASHES_KEY))[PATHFINDER_HASHES_KEY] || {};
    if (current[operationName] === sha256Hash) return;
    await extensionApi.storage.session.set({
      [PATHFINDER_HASHES_KEY]: { ...current, [operationName]: sha256Hash }
    });
    await extensionApi.storage.session.remove(PLAYLISTS_CACHE_KEY);
  }

  async function pathfinderQueryHashes() {
    return (await extensionApi.storage.session.get(PATHFINDER_HASHES_KEY))[PATHFINDER_HASHES_KEY] || {};
  }

  async function spotifyTabs() {
    return extensionApi.tabs.query({ url: "https://open.spotify.com/*" });
  }

  async function refreshSpotifyToken() {
    const tabs = await spotifyTabs();
    await Promise.all(tabs.map((tab) =>
      extensionApi.tabs.sendMessage(tab.id, { action: "refresh-token" }).catch(() => {})
    ));
    if (tabs.length > 0) {
      await new Promise((resolve) => setTimeout(resolve, 900));
    }
    return tabs.length;
  }

  async function tokenSession({ refresh = true } = {}) {
    let session = (await extensionApi.storage.session.get(TOKEN_KEY))[TOKEN_KEY] || null;
    const stale = !session?.token || Number(session.expiresAt) <= Date.now() + 60_000;
    if (refresh && stale) {
      await refreshSpotifyToken();
      session = (await extensionApi.storage.session.get(TOKEN_KEY))[TOKEN_KEY] || null;
    }
    return session;
  }

  async function bridgeStatus() {
    const tabs = await spotifyTabs();
    const session = await tokenSession({ refresh: false });
    const readyAt = (await extensionApi.storage.session.get(CONTENT_READY_KEY))[CONTENT_READY_KEY] || 0;
    const tokenCaptured = Boolean(session?.token && Number(session.expiresAt) > Date.now());
    return {
      installed: true,
      spotifyTabOpen: tabs.length > 0,
      spotifyContentReady: tabs.length > 0 && Number(readyAt) > Date.now() - 30 * 60 * 1000,
      tokenCaptured,
      authenticated: tokenCaptured && session?.isAnonymous !== true,
      anonymous: tokenCaptured && session?.isAnonymous === true,
      expiresAt: Number(session?.expiresAt) || 0
    };
  }

  async function authenticatedToken() {
    await requireEnabled();
    const session = await tokenSession();
    if (!session?.token) {
      throw new Error("Ouvre open.spotify.com et connecte-toi pour activer l'extension");
    }
    if (Number(session.expiresAt) <= Date.now()) {
      throw new Error("La session Spotify a expiré. Recharge Spotify.");
    }
    if (session.isAnonymous === true) {
      throw new Error("Le WebPlayer Spotify est encore en mode anonyme");
    }
    return session.token;
  }

  async function handleYouPlayerRequest(message) {
    if (message.action === "status") {
      const active = await bridgeEnabled();
      return { ok: true, data: active
        ? { ...await bridgeStatus(), enabled: true }
        : { installed: true, enabled: false, authenticated: false, tokenCaptured: false } };
    }
    await requireEnabled();
    if (message.action === "get-playlists") {
      const data = await cachedSpotifyPlaylists();
      return { ok: true, data };
    }
    if (message.action === "get-playlist") {
      const data = await runSpotifyRequest(async (token) => fetchBrowserSpotifyPlaylist(
        token,
        message.playlistId,
        { queryHashes: await pathfinderQueryHashes() }
      ));
      return { ok: true, data };
    }
    if (message.action === "search") {
      const data = await runSpotifyRequest(async (token) => fetchBrowserSpotifySearch(
        token,
        message.query,
        { limit: message.limit, offset: message.offset, queryHashes: await pathfinderQueryHashes() }
      ));
      return { ok: true, data };
    }
    if (message.action === "get-album") {
      const data = await runSpotifyRequest(async (token) => fetchBrowserSpotifyAlbum(
        token,
        message.albumId,
        { queryHashes: await pathfinderQueryHashes() }
      ));
      return { ok: true, data };
    }
    if (message.action === "get-lyrics") {
      const data = await runSpotifyRequest(token => fetchBrowserSpotifyLyrics(token, message.trackId));
      return { ok: true, data };
    }
    if (message.action === "get-artist") {
      const data = await runSpotifyRequest(async (token) => fetchBrowserSpotifyArtist(
        token,
        message.artistId,
        { queryHashes: await pathfinderQueryHashes() }
      ));
      return { ok: true, data };
    }
    if (message.action === "open-spotify") {
      await extensionApi.tabs.create({ url: "https://open.spotify.com/collection/playlists" });
      return { ok: true, data: { opened: true } };
    }
    throw new Error("Action YouPlayer Spotify inconnue");
  }

  return {
    bridgeEnabled,
    setBridgeEnabled,
    storeSpotifyToken,
    storeSpotifyContentReady,
    storePathfinderOperation,
    handleYouPlayerRequest
  };
}
