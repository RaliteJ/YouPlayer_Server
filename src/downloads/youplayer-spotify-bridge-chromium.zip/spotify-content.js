const PAGE_SOURCE = "youplayer-spotify-page";
const CONTENT_SOURCE = "youplayer-spotify-content";
const extensionApi = globalThis.browser ?? globalThis.chrome;
const TOKEN_URL = "https://open.spotify.com/get_access_token?reason=transport&productType=web_player";
let enabled = false;

function sendToken(data) {
  if (!enabled) return Promise.resolve();
  return extensionApi.runtime.sendMessage({
    action: "spotify-token",
    token: data?.accessToken || data?.token,
    expiresAt: data?.accessTokenExpirationTimestampMs || data?.expiresAt,
    isAnonymous: data?.isAnonymous
  });
}

async function refreshTokenDirectly() {
  try {
    const response = await fetch(TOKEN_URL, {
      credentials: "include",
      cache: "no-store",
      headers: { Accept: "application/json" }
    });
    if (!response.ok) return;
    await sendToken(await response.json());
  } catch {
    // Le hook MAIN reste le mecanisme principal si Firefox refuse cette requete directe.
  }
}

function requestTokenRefresh() {
  if (!enabled) return;
  window.postMessage({
    source: CONTENT_SOURCE,
    type: "refresh-token"
  }, window.location.origin);
  refreshTokenDirectly();
}

window.addEventListener("message", (event) => {
  if (!enabled) return;
  if (event.source !== window || event.origin !== window.location.origin) return;
  const message = event.data;
  if (message?.source !== PAGE_SOURCE || message?.type !== "token") return;
  extensionApi.runtime.sendMessage({
    action: "spotify-token",
    token: message.token,
    expiresAt: message.expiresAt,
    isAnonymous: message.isAnonymous
  }).catch(() => {});
});

window.addEventListener("message", (event) => {
  if (!enabled) return;
  if (event.source !== window || event.origin !== window.location.origin) return;
  const message = event.data;
  if (message?.source !== PAGE_SOURCE || message?.type !== "pathfinder-operation") return;
  extensionApi.runtime.sendMessage({
    action: "spotify-pathfinder-operation",
    operationName: message.operationName,
    sha256Hash: message.sha256Hash
  }).catch(() => {});
});

extensionApi.runtime.onMessage.addListener((message) => {
  if (message?.action !== "refresh-token") return;
  requestTokenRefresh();
});

function applyEnabled(value) {
  enabled = value !== false;
  window.postMessage({ source: CONTENT_SOURCE, type: "bridge-enabled", enabled }, window.location.origin);
  if (enabled) {
    extensionApi.runtime.sendMessage({ action: "spotify-content-ready" }).catch(() => {});
    requestTokenRefresh();
  }
}

let settingsChanged = false;
extensionApi.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.bridgeEnabled) return;
  settingsChanged = true;
  applyEnabled(changes.bridgeEnabled.newValue);
});
extensionApi.storage.local.get("bridgeEnabled").then(settings => {
  if (!settingsChanged) applyEnabled(settings.bridgeEnabled);
}).catch(() => {});
